# UTS Project for Internet Programming

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## This is about create Personal Portfolio using React JS Framework

Hello My name is Wendi Kardian (2100016) , i'm student of Computer Science Education in Education Univercity of Indonesia ... here is my final project for this midterm exaam 
