package main

import "fmt"

func main() {
    weather := "sunny"
    
    // Print "Today, the weather is ____" using Printf method from the fmt package
    fmt.Printf("Today, the weather is %s", weather)

}
