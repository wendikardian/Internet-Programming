package main

import "fmt"

func main() {
    // Print every integer from 1 to 100
    for i := 1; i<= 100; i++{
        fmt.Println(i)
    }
    
}
