package main

import "fmt"

func main() {
    month := 9
    day := 5
    
    // Print "The date today is ____/____" using fmt.Printf
    
    fmt.Printf("The date today is %d/%d", month, day)
}
