package main

func main() {
    // Remove the println line below because s1 has not yet been declared
    
    s1 := "Hi, "
    s2 := "world"
    
    // Change the value that the variable was given when it was defined
    s1 = "Hello, "
    // Since the s1 variable is a string type, remove the line below
    
    // Print the values of variables s1 and s2
    println(s1, s2)
    
    
}
