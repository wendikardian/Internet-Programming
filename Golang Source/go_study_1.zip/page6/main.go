package main

func main() {
    // Combine the strings "Hello, " and "world", and print it
    println("Hello,"+"world")
    
    // Combine the strings "38" and "19", and print it
    println("38" + "19")
    
    // Print the sum of 38 and 19
    println(38 + 19)

}
