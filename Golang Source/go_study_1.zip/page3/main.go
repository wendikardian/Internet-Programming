package main

func main() {
    // Print "Hello, world"
    println("Hello, world");
    
    // This line should be a comment
    
}
