package main

func main() {
    n := 100
    // Subtract 10 from variable n and then assign the result back to n
    n -= 10
    
    println(n)
    
    
    m := 10
    // Add 1 to variable m and then assign the result back to m
    m ++
    
    println(m)
}
