package main

func main() {
    // Declare the message variable and assign "Hello, world"
    var message string =  "Hello, world"
    
    // Print the value of the message variable
    println(message)
    
}
